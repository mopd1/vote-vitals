"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
// Export the Lambda handler
var lambda_1 = require("./lambda");
Object.defineProperty(exports, "handler", { enumerable: true, get: function () { return lambda_1.handler; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsNEJBQTRCO0FBQzVCLG1DQUFtQztBQUExQixpR0FBQSxPQUFPLE9BQUEiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFeHBvcnQgdGhlIExhbWJkYSBoYW5kbGVyXG5leHBvcnQgeyBoYW5kbGVyIH0gZnJvbSAnLi9sYW1iZGEnOyJdfQ==