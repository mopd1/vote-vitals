import winston from 'winston';
declare const logger: winston.Logger;
export { logger };
