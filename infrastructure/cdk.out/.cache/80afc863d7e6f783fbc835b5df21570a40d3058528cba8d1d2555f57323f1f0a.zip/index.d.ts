export { handler } from './lambda';
